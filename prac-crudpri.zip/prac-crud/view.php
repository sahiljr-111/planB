<?php
    require "connection.php";

    if(isset($_GET['id'])){
        $id=$_GET['id'];
        $deletedata="delete  from `user` where `id`=".$id;
        mysqli_query($con,$deletedata);
        header("location:view.php");
    }
    if(isset($_POST['search'])){
        $searchname=$_POST['searchdata'];
        $sql="select * from `user` where name like '%$searchname%'";
    }
    else{
        $sql="select * from `user`";
    }
    $res=mysqli_query($con,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="post">
        <input type="text" name="searchdata">
        <input type="submit" name="search" value="search">
    </form>
    <table border="2">
        <tr>
            <th>id</th>
            <th>name</th>
            <th>gender</th>
            <th>country</th>
            <th>language</th>
        </tr>
        <?php
        while($data=mysqli_fetch_assoc($res))
        {
        ?>
        <tr>
            <td><?php echo $data['id']?></td>
            <td><?php echo $data['name']?></td>
            <td><?php echo $data['gender']?></td>
            <td><?php echo $data['country']?></td>
            <td><?php echo $data['language']?></td>
            <td><a href="view.php?id=<?php echo $data['id']?>">Delete</a>||<a href="index.php?id=<?php echo $data['id']?>">Edit</a><td>
        </tr>
        <?php
        }
        ?>
    </table>
</body> 
</html>
