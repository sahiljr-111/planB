<?php
require 'connection.php';
if (isset($_POST['submit'])) {
  $name = $_POST['name'];
  $age = $_POST['age'];
  $country = $_POST['country'];
  $gender = $_POST['gender'];
  $language = $_POST['language'];
  $lang = implode(",",$language);
  
  $query = "insert into data (name,age,country,gender,language) values ('$name','$age','$country','$gender','$lang')";
  mysqli_query($conn, $query);
  echo "<script>alert('data inserted')</script>";
}

$query = "select * from data";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>InsertData</title>
</head>

<body>
  <form action="" method="post">
    <table>
      <tr>
        <td>Name</td>
        <td><input type="text" name="name"></td>
      </tr>
      <tr>
        <td>Age</td>
        <td><input type="number" name="age"></td>
      </tr>
      <tr>
        <td>Country</td>
        <td>
          <select name="country">
            <option value="" selected hidden>Select Country</option>
            <option value="India">India</option>
            <option value="America">America</option>
            <option value="Rusia">Rusia</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>Gender</td>
        <td>
          <input type="radio" name="gender" value="male">Male
          <input type="radio" name="gender" value="female">Female
        </td>
      </tr>
      <tr>
        <td>Language</td>
        <td><input type="checkbox" name="language[]" value="Hindi">Hindi
          <input type="checkbox" name="language[]" value="English">English
          <input type="checkbox" name="language[]" value="Chinese">Chinese
        </td>
      </tr>
      <tr>
        <td></td>
        <td><input type="submit" name="submit" value="submit"></td>
      </tr>
    </table>
  </form>

  <table border="1">
    <tr>
      <td>Id</td>
      <td>Name</td>
      <td>age</td>
      <td>country</td>
      <td>gender</td>
      <td>language</td>
      <td>Action</td>
    </tr>
    <tr>
      <?php
      while ($row = mysqli_fetch_assoc($result)) {
        ?>
        <td>
          <?php echo $row['id']; ?>
        </td>
        <td>

          <?php echo $row['name']; ?>
        </td>
        <td>

          <?php echo $row['age']; ?>
        </td>
        <td>

          <?php echo $row['country']; ?>
        </td>
        <td>

          <?php echo $row['gender']; ?>
        </td>
        <td>

          <?php echo $row['language']; ?>
        </td>
        <td>
          <a href="update.php?upid=<?php echo $row['id']?>">UPDATE</a>
          <a href="delete.php?did=<?php echo $row['id']?>">DELETE</a>
        </td>
      </tr>
      <?php
      }
      ?>
  </table>
</body>

</html>