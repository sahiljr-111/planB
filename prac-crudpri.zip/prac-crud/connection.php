<?php
    $con=mysqli_connect("localhost","root","");
   
    $sql = "CREATE DATABASE myDB";
    if (mysqli_query($con, $sql)) {
        echo "Database created successfully";
    } else {
        echo "Error creating database: " . mysqli_error($con);
    }
?>