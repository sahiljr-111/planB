﻿Imports System.Data
Partial Class product
    Inherits System.Web.UI.Page
    Dim ds As New DataSet
    Dim s1 As New Class1

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            fillp()
        End If
    End Sub
    Public Sub fillp()
        ds = s1.display("select * from product")
        GridView1.DataSource = ds
        GridView1.DataBind()

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        s1.IUD("insert into product values(" & TextBox1.Text & ",'" & TextBox2.Text & "'," & TextBox3.Text & ")")
        Response.Redirect("~/home.aspx")
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        ds = s1.display("select * from product where pno=" & TextBox1.Text & " order by pno ")
        TextBox1.Enabled = False
        TextBox2.Text = ds.Tables(0).Rows(0).Item("pname").ToString
        TextBox3.Text = ds.Tables(0).Rows(0).Item("price").ToString
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        s1.IUD("update product set pname='" & TextBox2.Text & "',price=" & TextBox3.Text & " where pno=" & TextBox1.Text & "")
        Response.Redirect("~/home.aspx")
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        s1.IUD("delete from product where pno=" & TextBox1.Text & "")
        Response.Redirect("~/home.aspx")
    End Sub
End Class
