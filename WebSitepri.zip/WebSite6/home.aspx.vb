﻿Imports System.Data
Partial Class home
    Inherits System.Web.UI.Page
    Dim ds As New DataSet
    Dim s1 As New Class1

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ds = s1.display("select * from product")
            GridView1.DataSource = ds
            GridView1.DataBind()
            DropDownList1.DataSource = ds
            DropDownList1.DataTextField = "pname"
            DropDownList1.DataValueField = "price"
            DropDownList1.DataBind()
        End If
    End Sub

    Protected Sub TextBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        ds = s1.display("select * from product where pno=" & TextBox1.Text & "")
        GridView1.DataSource = ds.Tables(0)
        GridView1.DataBind()
    End Sub
End Class
