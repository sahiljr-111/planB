﻿Imports Microsoft.VisualBasic
Imports System.Data.OleDb
Imports System.Data

Public Class Class1
    Dim cn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\.net\WebSite6\Database1.accdb")
    Dim cm As OleDbCommand
    Dim da As OleDbDataAdapter
    Dim ds As New DataSet

    Public Sub IUD(ByVal str As String)
        If cn.State = ConnectionState.Closed Then
            cn.Open()
        End If
        cm = New OleDbCommand(str, cn)
        cm.ExecuteNonQuery()
        cn.Close()
    End Sub

    Public Function display(ByVal str As String) As DataSet
        da = New OleDbDataAdapter(str, cn)
        ds.Tables.Clear()
        da.Fill(ds)
        Return ds
    End Function

End Class


