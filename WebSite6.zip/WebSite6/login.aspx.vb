﻿Imports System.Data
Partial Class login
    Inherits System.Web.UI.Page
    Dim ds As New DataSet
    Dim s1 As New Class1

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim role As Char
        ds = s1.display("select role from login where username='" & TextBox1.Text & "' and password='" & TextBox2.Text & "'")
        If ds.Tables(0).Rows.Count > 0 Then
            Session("username") = TextBox1.Text
            role = ds.Tables(0).Rows(0).Item("role").ToString
            If role = "u" Then
                Response.Redirect("product.aspx")
            ElseIf role = "a" Then
                Response.Redirect("home.aspx")
            End If
       
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

    End Sub
End Class
