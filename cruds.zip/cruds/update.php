<?php
require 'connection.php';
$id = $_GET['upid'];
$query = "select * from data where id=$id";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);
$lang = $data['language'];
$la = explode(",", $lang);

if (isset($_POST['update'])) {
  $name = $_POST['name'];
  $age = $_POST['age'];
  $country = $_POST['country'];
  $gender = $_POST['gender'];
  $language = $_POST['language'];
  $lang = implode(",", $language);

  $query = "update data set name='$name', age='$age', country='$country',gender='$gender',language='$lang' where id=$id";
  $result = mysqli_query($conn,$query);
  if($result){
    header('location:index.php');
  }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Update</title>
</head>

<body>
  <form action="#" method="post">
    <table>
      <tr>
        <td>ID</td>
        <td><input type="text" value="<?php echo $data['id']; ?>" disabled></td>
      </tr>
      <tr>
        <td>Name</td>
        <td><input type="text" name="name" value="<?php echo $data['name']; ?>"></td>
      </tr>
      <tr>
        <td>Age</td>
        <td><input type="number" name="age" value="<?php echo $data['age']; ?>"></td>
      </tr>
      <tr>
        <td>Country</td>
        <td>
          <select name="country">
            <option value="<?php echo $data['country']; ?>" selected hidden><?php echo $data['country']; ?></option>
            <option value="Indaia">India</option>
            <option value="America">America</option>
            <option value="Rusia">Rusia</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>Gender</td>
        <td>

          <input type="radio" name="gender" value="male" <?php if ($data['gender'] == 'male') {
            echo "checked";
          } ?>>Male
          <input type="radio" name="gender" value="female" <?php if ($data['gender'] == 'female') {
            echo "checked";
          } ?>>Female
        </td>
      </tr>
      <tr>
        <td>Language</td>
        <td>
          <input type="checkbox" name="language[]" value="Hindi" <?php if (in_array('Hindi', $la)) {
            echo "checked";
          } ?>>Hindi
          <input type="checkbox" name="language[]" value="English" <?php if (in_array('English', $la)) {
            echo "checked";
          } ?>>English
          <input type="checkbox" name="language[]" value="Chinese" <?php if (in_array('Chinese', $la)) {
            echo "checked";
          } ?>>Chinese
        </td>
      </tr>
      <tr>
        <td></td>
        <td><input type="submit" name="update" value="Update"></td>
      </tr>
    </table>
  </form>
</body>

</html>