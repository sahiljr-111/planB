<?php
    require "connection.php";

    if(isset($_GET['id'])){
        $id=$_GET['id'];
        $sel="select * from user where id=".$id;
        $res=mysqli_query($con,$sel);
        $data=mysqli_fetch_assoc($res);
    }
    
    if(isset($_POST['submit'])){
        $name=$_POST['name'];                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
        $gender=$_POST['gender'];
        $country=$_POST['country'];
        $language=$_POST['language'];

        $lang="";
        foreach($language as $row){
            $lang .= $row . ",";
        }
        if($id>0)
        {
            $sql="update `user` set `name`='$name',`gender`='$gender',`country`='$country',`language`='$lang' where `id`=".$id;
        }
        else{
            $sql="insert into `user` (`name`,`gender`,`country`,`language`)values('$name','$gender','$country','$lang')";

        }
        mysqli_query($con,$sql);
        header("location:view.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="post">
        <table>
            <tr>
                <td>name</td>
                <td><input type="text" name="name" value="<?php echo @$data['name']?>"required></td>
            </tr>
            <tr>
                <td>gender</td> 
                <td>
                    <input type="radio" name="gender" id="" value="male">male
                    <input type="radio" name="gender" id="" value="female">female
                </td>
            </tr>
            <tr>
                <td>country</td>
                <td>        
                    <select name="country">
                        <option value="usa">usa</option>
                        <option value="india">india</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>language</td>
                <td>
                    <input type="checkbox" name="language[]" value="gujarati">gujarati
                    <input type="checkbox" name="language[]" value="hindi">hindi
                    <input type="checkbox" name="language[]" value="english">english
                </td>
            </tr>
            <tr>
                <td><input type="submit" name="submit" value="submit"></td>
            </tr>
        </table>
    </form>
</body>
</html>